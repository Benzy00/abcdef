google.maps.__gjsload__('stats', function(_) {
    var IEa = function(a) {
            _.F(this, a, 2)
        },
        JEa = function(a) {
            _.F(this, a, 6)
        },
        UH = function(a, b, c, d) {
            var e = {};
            e.host = document.location && document.location.host || window.location.host;
            e.v = a.split(".")[1] || a;
            e.fv = a;
            e.r = Math.round(1 / b);
            c && (e.client = c);
            d && (e.key = d);
            return e
        },
        LEa = function(a) {
            var b = document;
            this.i = KEa;
            this.h = a + "/maps/gen_204";
            this.g = b
        },
        VH = function(a, b, c) {
            var d = [];
            _.hc(a, function(e, f) {
                d.push(f + b + e)
            });
            return d.join(c)
        },
        MEa = function(a) {
            var b = {};
            _.hc(a, function(c, d) {
                b[encodeURIComponent(d)] = encodeURIComponent(c).replace(/%7C/g,
                    "|")
            });
            return VH(b, ":", ",")
        },
        NEa = function(a, b, c, d) {
            var e = _.be(_.pe, 0, 1);
            this.m = a;
            this.C = b;
            this.l = e;
            this.i = c;
            this.j = d;
            this.g = new _.QA;
            this.o = Date.now()
        },
        WH = function(a, b, c, d, e) {
            this.C = a;
            this.F = b;
            this.o = c;
            this.l = d;
            this.m = e;
            this.h = {};
            this.g = []
        },
        OEa = function(a, b, c) {
            var d = _.qea;
            this.i = a;
            _.L.bind(this.i, "set_at", this, this.j);
            _.L.bind(this.i, "insert_at", this, this.j);
            this.l = b;
            this.o = d;
            this.m = c;
            this.h = 0;
            this.g = {};
            this.j()
        },
        QEa = function(a, b, c, d, e) {
            var f = _.be(_.pe, 23, 500);
            var g = _.be(_.pe, 22, 2);
            this.m = a;
            this.o =
                b;
            this.G = f;
            this.F = g;
            this.l = c;
            this.i = d;
            this.j = e;
            this.h = new _.QA;
            this.g = 0;
            this.C = Date.now();
            PEa(this)
        },
        PEa = function(a) {
            window.setTimeout(function() {
                REa(a);
                PEa(a)
            }, Math.min(a.G * Math.pow(a.F, a.g), 2147483647))
        },
        REa = function(a) {
            var b = UH(a.o, a.l, a.i, a.j);
            b.t = a.g + "-" + (Date.now() - a.C);
            a.h.forEach(function(c, d) {
                c = c();
                0 < c && (b[d] = Number(c.toFixed(2)) + (_.Fga() ? "-if" : ""))
            });
            a.m.Nj({
                ev: "api_snap"
            }, b);
            ++a.g
        },
        XH = function() {
            this.h = _.I(_.pe, 6);
            this.i = _.I(_.pe, 16);
            if (_.sh[35]) {
                var a = _.re(_.pe);
                a = _.I(a, 11)
            } else a = _.Yq;
            this.g = new LEa(a);
            (a = _.hj) && new OEa(a, (0, _.Na)(this.g.Nj, this.g), !!this.h);
            this.o = _.I(_.se(_.pe), 1);
            this.G = {};
            this.F = {};
            this.C = {};
            this.m = _.be(_.pe, 0, 1);
            _.sg && (this.J = new QEa(this.g, this.o, this.m, this.h, this.i));
            a = this.l = new JEa;
            var b = _.I(_.se(_.pe), 1);
            a.H[1] = b;
            this.h && (this.l.H[2] = this.h);
            this.i && (this.l.H[3] = this.i)
        };
    _.D(IEa, _.E);
    var YH;
    _.D(JEa, _.E);
    var KEa = Math.round(1E15 * Math.random()).toString(36);
    LEa.prototype.Nj = function(a, b) {
        b = b || {};
        var c = _.gl().toString(36);
        b.src = "apiv3";
        b.token = this.i;
        b.ts = c.substr(c.length - 6);
        a.cad = MEa(b);
        a = VH(a, "=", "&");
        a = this.h + "?target=api&" + a;
        _.kd(new _.jd(this.g), "IMG").src = a;
        (b = _.C.__gm_captureCSI) && b(a)
    };
    NEa.prototype.h = function(a, b) {
        b = void 0 !== b ? b : 1;
        0 === this.g.size && window.setTimeout((0, _.Na)(function() {
            var c = UH(this.C, this.l, this.i, this.j);
            c.t = Date.now() - this.o;
            for (var d = this.g, e = {}, f = _.A(_.u(d, "keys").call(d)), g = f.next(); !g.done; g = f.next()) g = g.value, e[g] = d.get(g);
            _.lc(c, e);
            this.g.clear();
            this.m.Nj({
                ev: "api_maprft"
            }, c)
        }, this), 500);
        b = this.g.get(a, 0) + b;
        this.g.set(a, b)
    };
    WH.prototype.i = function(a) {
        this.h[a] || (this.h[a] = !0, this.g.push(a), 2 > this.g.length && _.ft(this, this.j, 500))
    };
    WH.prototype.j = function() {
        for (var a = UH(this.F, this.o, this.l, this.m), b = 0, c; c = this.g[b]; ++b) a[c] = "1";
        a.hybrid = +_.km();
        this.g.length = 0;
        this.C.Nj({
            ev: "api_mapft"
        }, a)
    };
    OEa.prototype.j = function() {
        for (var a; a = this.i.removeAt(0);) {
            var b = a.bx;
            a = a.timestamp - this.o;
            ++this.h;
            this.g[b] || (this.g[b] = 0);
            ++this.g[b];
            if (20 <= this.h && !(this.h % 5)) {
                var c = {
                    s: b
                };
                c.sr = this.g[b];
                c.tr = this.h;
                c.te = a;
                c.hc = this.m ? "1" : "0";
                this.l({
                    ev: "api_services"
                }, c)
            }
        }
    };
    QEa.prototype.register = function(a, b) {
        this.h.set(a, b)
    };
    XH.prototype.L = function(a) {
        a = _.yf(a);
        var b = this.G[a];
        b || (b = new WH(this.g, this.o, this.m, this.h, this.i), this.G[a] = b);
        return b
    };
    XH.prototype.K = function(a) {
        a = _.yf(a);
        this.F[a] || (this.F[a] = new NEa(this.g, this.o, this.h, this.i));
        return this.F[a]
    };
    XH.prototype.j = function(a) {
        if (this.J) {
            this.C[a] || (this.C[a] = new _.TA, this.J.register(a, function() {
                return b.Lb()
            }));
            var b = this.C[a];
            return b
        }
    };
    XH.prototype.N = function(a) {
        if (_.sg) {
            var b = this.l.clone(),
                c = Math.floor(Date.now() / 1E3);
            b.H[0] = c;
            c = new IEa(_.J(b, 5));
            c.H[0] = Math.round(1 / this.m);
            c.H[1] = a;
            a = this.g;
            c = {
                ev: "api_map_style"
            };
            var d = new _.lh;
            YH || (YH = {
                O: "issssm",
                Z: ["is"]
            });
            var e = YH;
            b = d.g(b.vb(), e);
            c.pb = encodeURIComponent(b).replace(/%20/g, "+");
            b = VH(c, "=", "&");
            _.kd(new _.jd(a.g), "IMG").src = a.h + "?target=api&" + b
        }
    };
    _.qf("stats", new XH);
});